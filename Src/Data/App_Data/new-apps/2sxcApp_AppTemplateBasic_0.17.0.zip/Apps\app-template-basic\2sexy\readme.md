# Template App: Basic v00.17.00

This is just a simple template app, which should be used for new apps.
It contains a basic structure and some instructions.

Note that the version number is set to 00.17.00.
This is the version of the template app, not the version of the app you are creating.

We set the second version number to match the 2sxc version we are using, so we can easily see which version of 2sxc the app was created with.
The third number is just a counter, which we increase when we make changes to the template app.

## Git Repo

This app is maintained by 2sic, and the official repo is at [app-template-basic](https://github.com/2sxc-dev/app-template-basic)
